This is our JAVA-DBMS project of Enterprise Resource Planning (ERP) or Inventory Management.
It provides end-to-end inventory management solution for businesses!
This is our system architecture diagram

![Image Description](https://github.com/himanshuchopade97/ERP/blob/main/system_architecture.jpg)


